import React, { Component } from 'react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import '../Css/displayNote.scss'
import { CardActions } from '@material-ui/core'
import ReminderComponent from './ReminderComponent';
import ColorComponent from './ColorComponent';
import ArchiveComponent from './ArchiveComponent';
import LabelComponent from './LabelComponent';
import EditNoteComponent from './EditNoteComponent';

class DisplayNote extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                title: props.noteData.title,
                description: props.noteData.description,
                archive:props.noteData.archive

            },
            id: props.noteData._id,
            editNote: false,
            open: false,
            cssId: "Display-note-card",
            display:"block"
        }
    }

    handleGetALLNotes= () =>{
        this.props.handleGetNotes();
    }
    handleClickOpen = () => {
        console.log('idddd', this.props.listView);

        this.setState({ open: true });
    };

    handleClose = () => {
        this.setState({ open: false });
    };

    changeDisplay = () =>{
        this.setState({display:"none"})
    }

    componentWillReceiveProps() {
        if (this.props.DisplayGrid) {
            this.setState({ cssId: this.props.listView })
        }
        else {
            this.setState({ cssId: "Display-note-card" })
        }
    }

    render() {
        console.log("NOTE DATA FOR ONE ", this.props.noteData)
        return (
            <div>
                {!this.state.open ?
                    <Card id={this.state.cssId} style={{display:this.state.display}}>
                        <div className="note-text-div">
                            <div className="title-div" >
                                <CardContent style={{ paddingLeft: "0px" }} onClick={() => this.handleClickOpen()}>
                                    {this.state.data.title}
                                </CardContent>
                            </div>
                            <div className="desc-div">
                                <CardContent style={{ padding: "0.50px" }} onClick={() => this.handleClickOpen()}>
                                    {this.state.data.description}
                                </CardContent>
                            </div>
                        </div>
                        <div className="Icon-div">
                            <CardActions>
                                <ReminderComponent />
                                <ColorComponent />
                                <ArchiveComponent changeDisplay={this.changeDisplay} id={this.state.id} handleGetNotes={this.handleGetALLNotes}/>
                                <LabelComponent changeDisplay={this.changeDisplay} id={this.state.id} handleGetNotes={this.handleGetALLNotes}/>
                            </CardActions>
                        </div>
                    </Card>
                    :
                    <EditNoteComponent
                        open={this.state.open}
                        handleClose={this.handleClose}
                        parentState={this.state}
                        handleGetNotes={this.props.handleGetNotes} />
                }
            </div>
        );
    }
}

export default DisplayNote;

// handleClose={this.handleClose}
// id={this.state.id}
// title={this.state.title}
// description={this.state.description}

