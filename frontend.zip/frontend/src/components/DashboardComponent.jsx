import React, { Component } from 'react';
import AppBarComponent from './AppBarComponent';
import CreateNoteComponent from './CreateNoteComponent';
import DisplayGrid from './DisplayGrid';
import { getAllNote } from '../services/NoteService'

class DashboardComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            noteData: []
        }
    }

    componentDidMount() {
        this.handleGetNotes()
    }

    async handleGetNotes  ()  {
        await getAllNote()
             .then((response) => {
                console.log('get all note data=====>', response.data.data)
                this.setState({ noteData: response.data.data, lastPage:response.data.totalpages})
                console.log('get all note data in state=====>', this.state.noteData)
             })
             .catch((error) => {
                console.log('get all note error =====>', error)
             })
     }
    getNotes = () =>{
        this.handleGetNotes()
    }
    
    render() {
        return (
            <div>
                <AppBarComponent props={this.props.props} handleGetNotes={this.handleGetNotes}/>
                <CreateNoteComponent handleGetNotes={this.getNotes} />

                    <DisplayGrid 
                    noteData={this.state.noteData} 
                    DisplayGrid={this.state.gridview} 
                    handleGetNotes={this.handleGetNotes}
                    listView="Display-note-card-list"/>
            </div>
        );
    }
}

export default DashboardComponent;