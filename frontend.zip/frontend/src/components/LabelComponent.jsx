import React, { Component } from 'react';
import MoreMenu from '@material-ui/icons/MoreVert';
import { Tooltip, IconButton, DialogActions, Dialog, createMuiTheme, MuiThemeProvider, Menu, MenuItem } from '@material-ui/core';
import { updateTrash } from '../services/NoteService';


const theme = createMuiTheme({
    overrides: {
        MuiMenu: {
            paper: {
                "height": "17%"
            }
        },
    //     MuiBackdrop: {
    //         root: {
    //             "position": "relative",
    //             "touch-action": "none",
    //             "background-color": "rgba(0, 0, 0, 0.0)",
    //             "-webkit-tap-highlight-color": "transparent"
    //         }
    //     }
    }
})

class LabelComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            openMore: false,
            anchorEl: null,
        }
    }

    handleMore = (event) => {
        this.setState({ openMore: true, anchorEl: event.currentTarget })
    }

    handleClose = () => {
        this.setState({ anchorEl: null });
    };

    handleDelete = () => {
        this.setState({ anchorEl: null });

        let tarshData = {noteId:this.props.id}
         updateTrash(tarshData)
        .then(async(response)=>{
            console.log('Trash note',response)
            this.props.changeDisplay()
            await this.props.handleGetNotes()
        })
        .catch((error)=>{
            console.log('trash error',error)
        })
    }

    render() {

        return (
            <div>
                <Tooltip title="More">
                    <IconButton
                        aria-owns={this.state.anchorEl ? 'simple-menu' : undefined}
                        aria-haspopup="true"
                        onClick={this.handleMore}>
                        <MoreMenu style={{ width: "17px" }} />
                    </IconButton>
                </Tooltip>
                <div>
                    <MuiThemeProvider theme={theme}>
                    <Menu
                        id="simple-menu"
                        anchorEl={this.state.anchorEl}
                        open={Boolean(this.state.anchorEl)}
                        onClose={this.handleClose}
                    >
                        <MenuItem onClick={this.handleDelete}>Delete note</MenuItem>
                        <MenuItem onClick={this.handleClose}>Add label</MenuItem>
                    </Menu>
                    </MuiThemeProvider>
                </div>

            </div>
        );
    }
}

export default LabelComponent;