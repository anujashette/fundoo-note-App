import React from 'react';
import Grid from '@material-ui/core/Grid';
import DisplayNote from './DisplayNote';

class DisplayGrid extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      gridCss : "mainnotes-grid"
    }
  }

  render() {
    if (this.props.noteData) {
      console.log(this.props.noteData, "NOTE DATA ")
      var notes = this.props.noteData.map((key, index) => {
        return <DisplayNote 
        handleGetNotes={this.props.handleGetNotes}  
        listView={this.props.listView}
        DisplayGrid={this.props.DisplayGrid}
        noteData={key} key={index} />
      })
    }
    else {
      return <p style={{margin:"200px",color:"#434343",fontSize:"20px"}}>Your notes appear here</p>
    }

    return (
      <div className="allnotes-div">
        {/* {this.props.DisplayGrid ?  */}
        <div 
        className= {this.state.gridCss}
        // className="mainnotes-list"
        >
          {notes}
        </div>
         {/* : */}
        {/* <Grid className="mainnotes-list" style={{
          display: "flow-root",
          justifyContent: "stretch"}}
          >
            {notes}
          </Grid> */}
          {/* }  */}
      </div>
    );
  }
}

export default DisplayGrid;