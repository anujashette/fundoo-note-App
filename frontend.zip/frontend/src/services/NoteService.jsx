import axios from 'axios'
const url = 'http://localhost:6006'
let loginToken = localStorage.getItem('LoginToken')

export function createNote(noteInput){
    console.log("user data",noteInput)
    return axios.post( url+ `/note/addnote`,noteInput,
    {
        headers:{
            token:loginToken
        }
    })
}

export function getAllNote(){
    console.log("note data",loginToken)
    return axios.get( url+ `/note/readnote?pageNo=${1}&size=${20}`,
    {
        headers:{
            token:loginToken
        }
    })
}

export function updateTitle(titleInput){
    console.log("user data",titleInput)
    return axios.put( url+ `/note/updatetitle`,titleInput,
    {
        headers:{
            token:loginToken
        }
    })
}

export function updateDescription(DescriptionInput){
    console.log("user data",DescriptionInput)
    return axios.put( url+ `/note/updatedesc`,DescriptionInput,
    {
        headers:{
            token:loginToken
        }
    })
}

export function updateArchive(archiveInput){
    console.log("user data",archiveInput)
    return axios.put( url+ `/note/updatearchive`,archiveInput,
    {
        headers:{
            token:loginToken
        }
    })
}

export function updateTrash(trashInput){
    console.log("note deleted",trashInput)
    return axios.put( url+ `/note/updatetrash`,trashInput,
    {
        headers:{
            token:loginToken
        }
    })
}